﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WCT.Framework.Extensions;
using WCT.SharePoint.Common;
using Microsoft.VisualStudio.SharePoint;

namespace WCT.SharePoint.SolutionModel
{
    public class VSWebPartItem : VSModuleItem
    {

        public VSWebPartItem(FeatureDefinition feature) 
        {
            this.Feature = feature;
            this.Name = "WebPart_" + Guid.NewGuid();
            this.TypeName = Constants.SPTypeNameWebPart;
            this.GroupName = "WebParts";
            this.SupportedDeploymentScopes = "Web, Site";
            this.DefaultDeploymentType = DeploymentType.ElementFile;
        }


    }
}
