﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WCT.SharePoint.SolutionModel
{
    public class VSFeatureItem : VSSharePointItem
    {
        public FeatureDefinition Feature { get; set; }

        public virtual ElementDefinitionCollection GetElementManifest()
        {
            return null;
        }


    }
}
