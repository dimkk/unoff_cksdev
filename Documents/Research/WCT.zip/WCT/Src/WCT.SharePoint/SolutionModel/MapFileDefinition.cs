﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.SharePoint.Features;

namespace WCT.SharePoint.SolutionModel
{
    public partial class MapFileDefinition
    {
        public void Setup(IMapFileUpgradeAction action)
        {
            action.FromPath = this.FromPath;
            action.ToPath = this.ToPath;
        }
    }
}
