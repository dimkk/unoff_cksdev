﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WCT.Framework.IO;
using WCT.Framework.Extensions;
using WCT.SharePoint.Common;
using Microsoft.VisualStudio.SharePoint;

namespace WCT.SharePoint.SolutionModel
{
    public abstract class VSSharePointItem
    {
        private string _name = null;
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = FileSystem.MakeSafeFilename(value, ' ');
                if (String.IsNullOrEmpty(_name))
                {
                    // Ensure that there is a name, no matter what!
                    _name = FileSystem.MakeSafeFilename(Guid.NewGuid().ToString(), ' ');
                }
            }
        }

        private string _supportedTrustLevels = "All";
        public string SupportedTrustLevels
        {
            get { return _supportedTrustLevels; }
            set { _supportedTrustLevels = value; }
        }


        public string SupportedDeploymentScopes = "Web, Site, WebApplication, Farm";

        public String TypeName = Constants.SPTypeNameGenericElement;

        public string GroupName { get; set; }

        public DeploymentType DefaultDeploymentType { get; set; }


        //public List<VSSharePointItem> Children = new List<VSSharePointItem>();

        public List<ProjectFile> Files = new List<ProjectFile>();


        private VSSharePointItemCollection _vsItems = new VSSharePointItemCollection();
        public VSSharePointItemCollection VSItems
        {
            get { return _vsItems; }
            set { _vsItems = value; }
        }


        public void AddCodeFile(Context wctContext, string className)
        {
            ClassInformationCollection classes = wctContext.SourceProject.Classes.GetValue(className);
            if (classes != null)
            {
                foreach (ClassInformation classInfo in classes)
                {
                    if (!classInfo.File.Referenced)
                    {
                        this.AddProjectFile(classInfo.File);
                    }
                }
            }


        }

        public ProjectFile AddProjectFile(Context wctContext, string fullname)
        {
            return AddProjectFile(wctContext, fullname, null, this.DefaultDeploymentType);
        }

        public ProjectFile AddProjectFile(Context wctContext, string fullname, DeploymentType deploymentType)
        {
            return AddProjectFile(wctContext, fullname, null, deploymentType);
        }

        public ProjectFile AddProjectFile(Context wctContext, string fullname, string localName)
        {
            return AddProjectFile(wctContext, fullname, localName, this.DefaultDeploymentType);
        }

        public ProjectFile AddProjectFile(Context wctContext, string fullname, string localName, DeploymentType deploymentType)
        {
            ProjectFile prjFile = wctContext.SourceProject.Files.GetValue(fullname);
            if (prjFile != null)
            {
                AddProjectFile(prjFile);
                prjFile.SPDeploymentType = deploymentType;
                if (!String.IsNullOrWhiteSpace(localName))
                {
                    prjFile.LocalName = localName;
                }
            }
            return prjFile;
        }

        public void AddProjectFile(ProjectFile file)
        {
            this.Files.Add(file);
            file.SPDeploymentType = this.DefaultDeploymentType;
            file.Referenced = true;
        }


    }
}
