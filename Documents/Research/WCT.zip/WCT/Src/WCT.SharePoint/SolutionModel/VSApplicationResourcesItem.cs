﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WCT.SharePoint.Common;
using Microsoft.VisualStudio.SharePoint;

namespace WCT.SharePoint.SolutionModel
{
    public class VSApplicationResourcesItem : VSSharePointItem
    {

        public VSApplicationResourcesItem()
        {
            this.Name = "ApplicationResources";
            this.TypeName = Constants.SPTypeNameGenericElement;
            this.GroupName = "Resources";
            this.SupportedDeploymentScopes = "None";
            this.DefaultDeploymentType = DeploymentType.ApplicationResource;
        }

    }
}
