﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WCT.SharePoint.Common;
using Microsoft.VisualStudio.SharePoint;

namespace WCT.SharePoint.SolutionModel
{
    public class VSListDefinitionItem : VSFeatureItem
    {

        private ListTemplateDefinition _listTemplate = null;

        public ListTemplateDefinition ListTemplate
        {
            get { return _listTemplate; }
            set
            {
                _listTemplate = value;
                if (_listTemplate != null && !String.IsNullOrEmpty(_listTemplate.Name))
                {
                    this.Name = _listTemplate.Name;
                }
            }
        }


        public VSListDefinitionItem(FeatureDefinition feature)
        {
            this.Feature = feature;
            this.Name = "ListDefinition_" + Guid.NewGuid();
            this.TypeName = Constants.SPTypeNameListDefinition;
            this.GroupName = "ListDefinitions";
            this.SupportedDeploymentScopes = "Web, Site";
            this.DefaultDeploymentType = DeploymentType.ElementFile;
        }

        public VSListDefinitionItem(FeatureDefinition feature, ListTemplateDefinition listTemplate) : this(feature)
        {
            this.ListTemplate = listTemplate;
        }

        public override ElementDefinitionCollection GetElementManifest()
        {
            ElementDefinitionCollection elements = new ElementDefinitionCollection();

            elements.Items = new object[] { this.ListTemplate};

            return elements;
        }
    }
}
