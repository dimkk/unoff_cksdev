﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using WCT.SharePoint.Common;
using Microsoft.VisualStudio.SharePoint;

namespace WCT.SharePoint.SolutionModel
{
    public class ClassFile : ProjectFile
    {
        public IList<ClassInformation> Classes { get; set; }

        public ClassFile()
        {
            this.SPDeploymentType = DeploymentType.NoDeployment;
        }

        public ClassFile(FileInfo info)
        {
            this.Info = info;
            this.SPDeploymentType = DeploymentType.NoDeployment;
        }
    }
}
