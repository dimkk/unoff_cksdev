﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WCT.SharePoint.Common;
using Microsoft.VisualStudio.SharePoint;

namespace WCT.SharePoint.SolutionModel
{
    public class VSGenericItem : VSFeatureItem
    {

        private object _item = null;

        public Object Item
        {
            get { return _item; }
            set
            {
                _item = value;
                if (_item != null)
                {
                    Type type = _item.GetType();
                    this.Name = type.Name + "_" + Guid.NewGuid();
                }
            }
        }



        public VSGenericItem(FeatureDefinition feature)
        {
            this.Feature = feature;
            this.Name = "Generic_" + Guid.NewGuid();
            this.TypeName = Constants.SPTypeNameGenericElement;
            this.GroupName = "Generic";
            this.SupportedDeploymentScopes = "Web, Site";
            this.DefaultDeploymentType = DeploymentType.ElementFile;
        }

        public override ElementDefinitionCollection GetElementManifest()
        {
            if (this.Item != null)
            {
                ElementDefinitionCollection elements = new ElementDefinitionCollection();

                elements.Items = new object[] { this.Item };

                return elements;
            }
            return null;
        }
    }
}
