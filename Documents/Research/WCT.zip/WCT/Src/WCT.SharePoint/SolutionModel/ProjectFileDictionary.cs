﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WCT.SharePoint.SolutionModel
{
    public class ProjectFileDictionary : Dictionary<string, ProjectFile>
    {
        public ProjectFileDictionary() : base(StringComparer.OrdinalIgnoreCase)
        {
        }
    }
}
