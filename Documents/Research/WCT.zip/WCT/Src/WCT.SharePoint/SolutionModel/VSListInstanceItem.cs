﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WCT.SharePoint.Common;
using Microsoft.VisualStudio.SharePoint;

namespace WCT.SharePoint.SolutionModel
{
    public class VSListInstanceItem : VSFeatureItem
    {

        private ListInstanceDefinition _listInstance = null;

        public ListInstanceDefinition ListInstance
        {
            get { return _listInstance; }
            set
            {
                _listInstance = value;
                if (_listInstance != null && !String.IsNullOrEmpty(_listInstance.Title))
                {
                    this.Name = _listInstance.Title;
                }
            }
        }


        public VSListInstanceItem(FeatureDefinition feature)
        {
            this.Feature = feature;
            this.Name = "ListInstance_" + Guid.NewGuid();
            this.TypeName = Constants.SPTypeNameListInstance;
            this.GroupName = "ListInstances";
            this.SupportedDeploymentScopes = "Web, Site";
            this.DefaultDeploymentType = DeploymentType.ElementFile;
        }

        public VSListInstanceItem(FeatureDefinition feature, ListInstanceDefinition listInstance) : this(feature)
        {
            this.ListInstance = listInstance;
        }

        public override ElementDefinitionCollection GetElementManifest()
        {
            ElementDefinitionCollection elements = new ElementDefinitionCollection();

            elements.Items = new object[] { this.ListInstance};

            return elements;
        }
    }
}
