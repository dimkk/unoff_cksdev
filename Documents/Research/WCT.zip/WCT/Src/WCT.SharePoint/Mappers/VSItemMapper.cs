﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WCT.SharePoint.SolutionModel;
using Microsoft.VisualStudio.SharePoint;
using System.IO;
using EnvDTE;
using WCT.Framework.IO;
using WCT.Framework.Extensions;
using WCT.Framework.Serialization;

namespace WCT.SharePoint.Mappers
{
    public class VSItemMapper
    {

        public Context WCTContext { get; set; }


        public VSItemMapper(Context context)
        {
            this.WCTContext = context;
        }




        public void CreateItems(FeatureDefinition featureDef, ISharePointProjectFeature spFeature)
        {
            CreateItems(null, featureDef.SharePointItems, spFeature);
        }

        public void CreateItem(VSSharePointItem vsItem)
        {
            if (vsItem == null)
            {
                return;
            }

            List<VSSharePointItem> list = new List<VSSharePointItem>();
            list.Add(vsItem);
            CreateItems(null, list, null);
        }


        private void CreateItems(string subFolder, IList<VSSharePointItem> vsItems, ISharePointProjectFeature spFeature)
        {
            if (vsItems != null)
            {
                foreach (VSSharePointItem vsItem in vsItems)
                {
                    string currentFolder = subFolder;
                    if (String.IsNullOrEmpty(currentFolder))
                    {
                        currentFolder = @"Items\" + vsItem.GroupName;
                    }

                    ISharePointProjectItem spItem = CreateSPI(currentFolder, vsItem);
                    if (spFeature != null)
                    {
                        spFeature.ProjectItems.Add(spItem);
                    }

                    string childFolder = currentFolder + @"\" + spItem.Name;
                    CreateItems(childFolder, vsItem.VSItems, spFeature);
                }
            }
        }


        private ISharePointProjectItem CreateSPI(string subFolder, VSSharePointItem vsItem)
        {
            string spiName = GetSPIName(vsItem.Name);

            // Create a new Visual Studio SharePoint Item
            ISharePointProjectItem projectItem = this.WCTContext.SharePointProject.ProjectItems.Add(subFolder, spiName, vsItem.TypeName, true);
            
            //// Add the new Item to the package, if it do not exit.
            //if(!this.WCTContext.SharePointProject.Package.ProjectItems.Contains(projectItem))
            //{
            //    this.WCTContext.SharePointProject.Package.ProjectItems.Add(projectItem);
            //}

            if (vsItem is VSFeatureItem)
            {
                VSFeatureItem vsFeatureItem = (VSFeatureItem)vsItem;
                ElementDefinitionCollection elements = vsFeatureItem.GetElementManifest();
                if (elements != null)
                {
                    // Add the Elements.xml file
                    String xml = Serializer.ObjectToXML(elements);
                    string manifestFilename = Path.Combine(projectItem.FullPath, "Elements.xml");
                    File.WriteAllText(manifestFilename, xml);
                    ISharePointProjectItemFile spiElementFile = projectItem.Files.AddFromFile(manifestFilename);
                    spiElementFile.DeploymentType = DeploymentType.ElementManifest;
                }
            }
            
            // Copy resource files into the vsItem
            foreach (ProjectFile file in vsItem.Files)
            {
                if (!file.Used && File.Exists(file.Info.FullName))
                {
                    string target = Path.Combine(projectItem.FullPath, file.LocalName);
                    FileSystem.Copy(file.Info.FullName, target);
                    ISharePointProjectItemFile spiFile = projectItem.Files.AddFromFile(target);
                    spiFile.DeploymentType = file.SPDeploymentType;
                    file.Used = true;
                }
            }

            return projectItem;
        }

        /// <summary>
        /// Gets the SPI name. Checks if the name has already been used and then adds a number to the end of the name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private string GetSPIName(string name)
        {
            string result = name;
            int count = 2; // Start from number two, because the first SPI is without number

            if (this.WCTContext.SPINames.ContainsKey(name))
            {
                count = this.WCTContext.SPINames[name];
                result = name + count;
                count++;
            }

            this.WCTContext.SPINames.AddOrReplace(name, count);

            return name;
        }

    }
}
