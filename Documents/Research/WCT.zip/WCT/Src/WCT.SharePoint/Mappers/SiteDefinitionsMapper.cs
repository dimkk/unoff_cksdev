﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WCT.Framework.Extensions;
using WCT.SharePoint.SolutionModel;
using WCT.SharePoint.Common;
using WCT.SharePoint.Resources;

namespace WCT.SharePoint.Mappers
{
    public class SiteDefinitionsMapper
    {
        
        public Context WCTContext { get; set; }


        public SiteDefinitionsMapper(Context context)
        {
            this.WCTContext = context;
        }

        public void Map()
        {
            VSItemMapper itemMapper = new VSItemMapper(this.WCTContext);

            foreach (var siteDef in this.WCTContext.Solution.SiteDefinitionManifests.AsSafeEnumable())
            {
                try
                {
                    itemMapper.CreateItem(siteDef.VSItem);
                }
                catch (Exception ex)
                {
                    Logger.LogError(String.Format(StringResources.Strings_Errors_MapSiteDefinition, siteDef.Location, ex.ToString()));
                }
            }
        }
    }
}
