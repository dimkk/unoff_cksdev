using System;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.TextManager.Interop;
using WCT.Framework.Extensions;
using WCT.SharePoint.Common;
using WCT.SharePoint.Resources;
using WCT.SharePoint.ModelCreators;
using WCT.SharePoint.SolutionModel;
using WCT.SharePoint.Mappers;


namespace WCT.SharePoint
{

    public class ProjectHandler
    {
        public Context WCTContext { get; set; }

        public ProjectHandler(Context context)
        {
            this.WCTContext = context;
            Logger.DesignTimeEnvironment = this.WCTContext.DteProject.DTE;
        }

        public void Update()
        {
            if (".csproj".EqualsIgnoreCase(Path.GetExtension(this.WCTContext.SourceProject.FileName))
                || ".vbproj".EqualsIgnoreCase(Path.GetExtension(this.WCTContext.SourceProject.FileName)))
            {
                this.UpdateProject();

                this.UpdateAssemblyInfoFile();
            }
        }

        private void UpdateProject()
        {
            Logger.LogStatus(StringResources.String_LogMessages_BuildingSourceModel);

            SolutionCreator creator = new SolutionCreator(this.WCTContext);
            this.WCTContext.Solution = creator.LoadSolution();

            Logger.LogStatus(String.Format(StringResources.String_LogMessages_MappingTarget, this.WCTContext.TargetProjectFilePath));

            VisualStudioProjectMapper vsMapper = new VisualStudioProjectMapper(this.WCTContext);
            vsMapper.MapProject();

            SolutionMapper spMapper = new SolutionMapper(this.WCTContext);
            spMapper.Map();

            // Add all the project files that have not been added yet.
            vsMapper.MapProjectFiles();
        }

        public void UpdateAssemblyInfoFile()
        {
            const string strAssemblyInfoFile = "Properties\\AssemblyInfo.cs";
            string strLineToAdd = "using System.Security;" + Environment.NewLine;

            string path = Path.Combine(Path.GetDirectoryName(this.WCTContext.TargetProjectFilePath), strAssemblyInfoFile);

            string text = File.ReadAllText(path);

            if (text.IndexOf("System.Security;") < 0)
            {
                int index = text.IndexOf("using System");
                index = (index < 0) ? 0 : index;

                text.Insert(index, strLineToAdd);
                File.WriteAllText(path, text);
            }
        }
    }
}