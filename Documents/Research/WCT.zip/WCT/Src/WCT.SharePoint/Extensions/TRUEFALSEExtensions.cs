﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WCT.SharePoint.SolutionModel;

namespace WCT.SharePoint.Extensions
{
    public static class TRUEFALSEExtensions
    {
        public static bool IsTrue(TRUEFALSE value)
        {
            bool result = false;

            result = (value == TRUEFALSE.True || value == TRUEFALSE.TRUE || value == TRUEFALSE.@true);

            return result;
        }
    }
}
